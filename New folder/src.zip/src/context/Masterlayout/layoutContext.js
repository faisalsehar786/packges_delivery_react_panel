import { createContext } from 'react'

const layoutContext = createContext()

export default layoutContext
