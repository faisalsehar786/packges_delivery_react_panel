import Swal from 'sweetalert2'

const SweetAlert2 = Swal

export default SweetAlert2
